Good Day Goods — Color Edit Edition

Open index.html in your browser to preview the website.
Use EDITING_GUIDE.txt for simple steps to change the white, black, and beige mockup colors in Notepad.
The product mockup illustration is built into index.html, so you do not need a separate image folder.

This is a local storefront prototype. Real payment processing and Printify order fulfillment are not connected.
